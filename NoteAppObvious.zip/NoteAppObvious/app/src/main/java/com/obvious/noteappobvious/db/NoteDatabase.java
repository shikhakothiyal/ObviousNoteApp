package com.obvious.noteappobvious.db;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.obvious.noteappobvious.dao.DaoAccess;
import com.obvious.noteappobvious.model.NoteModel;

@Database(entities = {NoteModel.class}, version = 1, exportSchema = false)
public abstract class NoteDatabase extends RoomDatabase {

    public abstract DaoAccess daoAccess();
}
