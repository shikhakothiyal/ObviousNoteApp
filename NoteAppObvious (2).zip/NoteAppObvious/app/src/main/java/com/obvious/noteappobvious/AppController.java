package com.obvious.noteappobvious;

import android.app.Application;

public class AppController extends Application {


}
