package com.obvious.noteappobvious.Utils;

import android.app.Activity;
import android.content.Intent;

import com.obvious.noteappobvious.AppConstants;
import com.obvious.noteappobvious.UI.Activity.AddNoteActivity;
import com.obvious.noteappobvious.UI.Activity.PwdActivity;
import com.obvious.noteappobvious.model.NoteModel;


public class NavigatorUtils implements AppConstants {


    public static void redirectToPwdScreen(Activity activity,
                                           NoteModel note) {
        Intent intent = new Intent(activity, PwdActivity.class);
        intent.putExtra(INTENT_TASK, note);
        activity.startActivityForResult(intent, ACTIVITY_REQUEST_CODE);
    }


    public static void redirectToEditTaskScreen(Activity activity,
                                                NoteModel note) {
        Intent intent = new Intent(activity, AddNoteActivity.class);
        intent.putExtra(INTENT_TASK, note);
        activity.startActivityForResult(intent, ACTIVITY_REQUEST_CODE);
    }

    public static void redirectToViewNoteScreen(Activity activity,
                                                NoteModel note) {
        Intent intent = new Intent(activity, AddNoteActivity.class);
        intent.putExtra(INTENT_TASK, note);
        intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
        activity.startActivity(intent);
        activity.finish();
    }
}
