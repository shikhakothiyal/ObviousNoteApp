package com.obvious.noteappobvious.dao;




import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.obvious.noteappobvious.model.NoteModel;

import java.util.List;

@Dao
public interface DaoAccess {

    @Insert
    Long insertTask(NoteModel note);


    @Query("SELECT * FROM NoteModel ORDER BY created_at desc")
    LiveData<List<NoteModel>> fetchAllTasks();


    @Query("SELECT * FROM NoteModel WHERE id =:taskId")
    LiveData<NoteModel> getTask(int taskId);


    @Update
    void updateTask(NoteModel note);


    @Delete
    void deleteTask(NoteModel note);
}
