/*
package com.obvious.noteappobvious.CustomHeader;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import com.obvious.noteappobvious.R;

public class CustomTextView extends TextView {

    public CustomTextView(Context context) {
        super(context);
    }

    public CustomTextView(Context context, AttributeSet attrs) {

        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs,
                R.styleable.CustomTextView);
        final String fontPath = a.getString(R.styleable.CustomTextView_textFontPath);
        a.recycle();
        setTypeFace(fontPath);
    }

    public CustomTextView(Context context, AttributeSet attrs, int defStyle) {

        super(context, attrs, defStyle);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView);
        final String fontPath = a.getString(R.styleable.CustomTextView_textFontPath);
        a.recycle();
        setTypeFace(fontPath);
    }

    public void setTypeFace(String fontPath) {
        if(fontPath != null) {
            Typeface myTypeFace = Typeface.createFromAsset(this.getContext().getAssets(), fontPath);
            this.setTypeface(myTypeFace);
        }
    }
}*/
